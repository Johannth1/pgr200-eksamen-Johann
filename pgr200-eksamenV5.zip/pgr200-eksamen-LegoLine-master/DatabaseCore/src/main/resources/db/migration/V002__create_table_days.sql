
create table if not exists days(
  days_id serial primary key,
  days_days varchar, -- not null,
  days_date varchar -- not null
);