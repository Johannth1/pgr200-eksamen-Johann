# Mappeinnlevering eksamen 
## Gruppe 16 - Johann og Line 


Av        Line Nathalie Rønning Og   Johan Th. Næss 

FeideID   Ronlin17                   Nesjoh17


----------------
Line Coverage (Link) 

https://ibb.co/hrJn8L

https://ibb.co/fpcfTL



---------------

###Selvevaluering av hvordan man jobbet sammen

Vi har hovedsaklig jobbet på skolen, vi fant fort ut at det var best å bruke én datamaskin. Så det ble egentlig bare par programmering hele veien. Der vi brukte én datamaskin til å slå opp for å løse problemer vi hadde underveis, og den andre maskinen til å skrive koden på. 
Dette fungerte veldig bra, da det er lettere med to personer. Det var litt uvant i starten da vi ikke er vant med at noen sitter og ser på når vi sitter å programmerer, men det gikk fort over. 
Vi opplevde at det ble mye bedre på denne måten vi gjorde det, siden det var lettere å oppdage feil i koden når én kodet og én så på. Slik kunne vi lettere få fikset småfeil(og store feil..) med en gang uten å gå tilbake senere uten å ha noen anelse om hva som var galt. 
Det var også mye mer effektivt til tider i og med at vi hadde "dobbelt opp" med kunnskap, så hvis den ene sto fast om hva vi skulle gjøre videre kunne den andre foreslå hva den andre skulle skrive. Eller hvordan vi skulle løse problemet vi hadde kommet oss inn i. 
Vi har jobbet litt hjemme, men for det meste har vi trivdes med å sitte sammen på skolen og kode. Vi har brukt Slack til å kommunisere oss i mellom og for å sende filer/kode til hverandre. 
Vi har flere prosjekter i andre fag samtidig, så da har vi prøvd å møtes de dagene vi har kunnet, der vi ikke var opptatt med de andre gruppene i de fagene vi hadde. 

------------

###Databasediagram

Se images fil.

----------------
###Video

I denne videoen parprogrammerer vi. Det ble bare tid til én test, siden vi brukte over en time på å få den til å bli grønn. :hankey: 
Videoen skulle jo egentlig bare vart i 3-8 minutter, men siden videoen ble på over en time, måtte vi ta i bruk av noen kreative løsninger for å korte ned på filmen. 
Så da ble videoen klippet, og hastigheten på filmen ble også økt, men ikke for mye så man ikke fikk med seg hva som skjedde. :construction_worker: 
Vil oppfordre til å stoppe videoen og se på problemene vi støter på underveis. Så du kan enkelt følge med på hvordan vi løste problemene og fikk koden til å kjøre grønt til slutt. :bug:  

Link

https://youtu.be/fuXUXFP1mjU

----------------

###Kommentarer til selve koden

Flertallsnavn på klasser: Vi er klar over at det er foretrukket praksis å skulle lage klasser med entallsnavn heller enn flertallsnavn, men det var noe vi hadde glemt da vi startet prosjektet.
Så hvis vi ikke har rettet opp i navngivningen innen mappen blir levert inn, er det rett og slett fordi vi heller har måttet prioritere annen funksjonalitet i koden.

11.11.2018 03:34
Hvis dette er koden som er den siste som er lagt inn, er det fremdeles en del som gjenstår for å få programmet til å kjøre sql-spørringer fra klient via server til databasen. Sannsynligvis har det hendt noe dramatisk som gjør at vi ikke har blitt ferdig.

----------------
