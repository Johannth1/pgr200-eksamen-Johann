create table if not exists days(
  id serial primary key,
  days_days varchar, -- not null,
  days_date varchar -- not null
);
