create table if not exists rooms (
    id serial primary key,
    rooms_room varchar not null
);