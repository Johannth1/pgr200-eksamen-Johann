create table if not exists timeslots (
    id serial primary key,
    timeslots_time varchar not null
);

