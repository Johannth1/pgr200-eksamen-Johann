public class ConferenceTest {
}
