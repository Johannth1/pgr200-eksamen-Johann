#Gjensidig evaluering til en annen gruppe 
## Gruppe som er blitt evaluert: 16
### Gruppe som har utført evaluering: 33

####Hva lærte vi av å se på koden? 
Det vi lærte av å se på, så var noen metoder som f.eks. CreateStandardRooms som ble brukt som vi ikke har. 
Det andre var at vi lærte av å bruke metoder fra en annen klasse til å bruke til test. 
Tredje som ble inserpert er navnoppgivning til metotoder som blir kalt.

####Hva tror du forfatter av koden kan ha nytte av å lære mer om? 
Det de kan lære er å dele klasse, interface i flere mapper der de kunne vært eget mappe hver. 
Det var en string som var tom som var mellom to andre string.
